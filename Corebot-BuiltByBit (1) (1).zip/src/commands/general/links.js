const Utils = require("../../modules/utils.js");
const { config, embeds } = Utils.variables;

module.exports = {
    name: 'links',
    run: async (bot, messageOrInteraction, args, { reply }) => {
        return new Promise(resolve => {
            let fields = Object.keys(config.Links).map(name => {
                return { name: name, value: config.Links[name] };
            });

            reply(Utils.setupMessage({
                configPath: embeds.Embeds.Links,
                fields: fields
            }));
            return resolve(true);
        });
    },
    description: "View links related to the Discord server",
    usage: 'links',
    aliases: [],
    arguments: []
};
// 482836   8501   fe301c3d179b70474f80a8e91ed222b8    95994   1716144902   5c9e263b836636dc6ae9b0d8b27728aa   %%__NONCE__%%