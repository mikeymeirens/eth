const Utils = require("../../modules/utils.js");
const Embed = Utils.Embed;
const request = require("request");
const lang = Utils.variables.lang;

module.exports = {
    name: "minecraftuser",
    run: async (bot, messageOrInteraction, args, { prefixUsed, reply }) => {
        return new Promise(async resolve => {
            if (!args[0]) {
                reply(Embed({ 
                    preset: 'invalidargs', 
                    usage: module.exports.usage
                }, { prefixUsed }), { ephemeral: true });

                return resolve();
            }

            let msg = await reply(Embed({ title: lang.MinecraftModule.Commands.Mcuser.FetchingData }));

            request({
                url: `https://api.mojang.com/users/profiles/minecraft/${args[0]}`,
                json: true
            }, async function (error, response, body) {
                if (error) {
                    Utils.error(error.message, error.stack, "mcuser.js:17", true);
                    reply(Embed({ preset: "console" }), { ephemeral: true });
                    return resolve();
                } else {
                    if (!body) {
                        reply(Embed({ 
                            preset: "error", 
                            description: lang.MinecraftModule.Commands.Mcuser.Errors.InvalidUsername, 
                            usage: module.exports.usage
                        }), { ephemeral: true });

                        return resolve();
                    }

                    msg.edit(Embed({
                        title: lang.MinecraftModule.Commands.Mcuser.UserInfo.Title.replace(/{user-name}/g, body.name),
                        fields: [
                            { name: lang.MinecraftModule.Commands.Mcuser.UserInfo.Fields[1], value: body.id },
                            { name: lang.MinecraftModule.Commands.Mcuser.UserInfo.Fields[2].Name, value: lang.MinecraftModule.Commands.Mcuser.UserInfo.Fields[2].Value.replace(/{namemc-link}/g, "https://namemc.com/profile/" + body.name) }
                        ],
                        thumbnail: lang.MinecraftModule.Commands.Mcuser.UserInfo.Image.replace(/{user-image}/g, `https://visage.surgeplay.com/bust/${body.id}`),
                        timestamp: new Date()
                    }));
                }
            });
        });
    },
    description: "View minecraft account information",
    usage: "mcuser <minecraft username>",
    aliases: [
        "mcuser", 
        "mcaccount",
        "namehistory"
    ],
    arguments: [
        {
            name: "username",
            description: "The username of the Minecraft account",
            required: true,
            type: "STRING"
        }
    ]
};
// 482836   8501   fe301c3d179b70474f80a8e91ed222b8    95994   1716144902   5c9e263b836636dc6ae9b0d8b27728aa   %%__NONCE__%%