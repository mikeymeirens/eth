const unlock = require("../../modules/methods/unlockChannel");

module.exports = {
    name: "unlock",
    run: async (bot, messageOrInteraction, args, { type, member, channel, reply }) => {
        return new Promise(async resolve => {
            resolve(await unlock(channel, member, true, reply, type));
        });
    },
    description: "Unlock the channel you are typing in",
    usage: "unlock",
    aliases: [],
    arguments: []
};
// 482836   8501   fe301c3d179b70474f80a8e91ed222b8    95994   1716144902   5c9e263b836636dc6ae9b0d8b27728aa   %%__NONCE__%%