const closeTicket = require("../../modules/methods/closeTicket");

module.exports = {
    name: "close",
    run: async (bot, messageOrInteraction, args, { member, channel, reply }) => {
        return new Promise(async resolve => {
            const response = await closeTicket(bot, args, member, channel, undefined, reply);

            if (response) return resolve(true);
            else return resolve();
        });
    },
    description: "Close the ticket you are typing in",
    usage: "close [reason]",
    aliases: [
        "ticketclose",
        "closeticket"
    ],
    arguments: [
        {
            name: "reason",
            description: "The reason for closing the ticket",
            required: false,
            type: "STRING"
        }
    ]
};
// 482836   8501   fe301c3d179b70474f80a8e91ed222b8    95994   1716144902   5c9e263b836636dc6ae9b0d8b27728aa   %%__NONCE__%%