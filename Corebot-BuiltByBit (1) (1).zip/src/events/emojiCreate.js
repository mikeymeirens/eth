const Utils = require('../modules/utils');
const { config, lang } = Utils.variables;

module.exports = async (bot, emoji) => {
    if (require('../modules/handlers/CommandHandler.js').commands.length > 0) {
        if (!config.Logs.Enabled.includes("EmojiCreated")) return;
        if (config.Other.IgnoredGuilds.includes(emoji.guild.id)) return;

        const logs = Utils.findChannel(config.Logs.Channels.EmojiCreated, emoji.guild);
        if (!logs) return;
        logs.send(Utils.Embed({
            author: lang.LogSystem.EmojiCreated.Author,
            description: lang.LogSystem.EmojiCreated.Description
                .replace(/{emoji}/g, emoji)
                .replace(/{name}/g, emoji.name)
                .replace(/{id}/g, emoji.id)
                .replace(/{time}/g, ~~(Date.now() / 1000))
        }));
    }
};
// 482836   8501   fe301c3d179b70474f80a8e91ed222b8    95994   1716144902   5c9e263b836636dc6ae9b0d8b27728aa   %%__NONCE__%%