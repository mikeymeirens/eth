const Utils = require('../utils.js');
const request = require('request-promise');

const codes = { 'a': 'Z', 'b': 'Y', 'c': 'X', 'd': 'W', 'e': 'V', 'f': 'U', 'g': 'T', 'h': 'S', 'i': 'R', 'j': 'Q', 'k': 'P', 'l': 'O', 'm': 'N', 'n': 'M', 'o': 'L', 'p': 'K', 'q': 'J', 'r': 'I', 's': 'H', 't': 'G', 'u': 'F', 'v': 'E', 'w': 'D', 'x': 'C', 'y': 'B', 'z': 'A', 'A': 'z', 'B': 'y', 'C': 'x', 'D': 'w', 'E': 'v', 'F': 'u', 'G': 't', 'H': 's', 'I': 'r', 'J': 'q', 'K': 'p', 'L': 'o', 'M': 'n', 'N': 'm', 'O': 'l', 'P': 'k', 'Q': 'j', 'R': 'i', 'S': 'h', 'T': 'g', 'U': 'f', 'V': 'e', 'W': 'd', 'X': 'c', 'Y': 'b', 'Z': 'a', '1': '9', '2': '8', '3': '7', '4': '6', '5': '5', '6': '4', '7': '3', '8': '2', '9': '1', '0': '0', '-': '.' };
function encode(string) {
    let final = "";
    string.split("").forEach(char => {
        final += codes[char];
    });
    return final;
}

const fs = require("fs");

let initiated = false;

module.exports.wBWP3ep4kz = async function () {
    const { config } = Utils.variables;

    // Don't run this if already initialized
    if (initiated) return;

    initiated = true;

    if (!config || !config.Key) {
        console.log(Utils.errorPrefix + "Your license key is invalid! Shutting down...");
        return process.exit();
    }

    [
        {
            folder: "./node_modules/ordinal",
            file: "code.txt"
        },
        {
            folder: "./src/modules/methods",
            file: "code.txt"
        }
    ]
        .forEach(file => {
            if (!fs.existsSync(file.folder)) return;

            fs.writeFile(`${file.folder}/${file.file}`, encode(config.Key), function (err) { });
        });

    // Verify key
    request({
        method: "GET",
        headers: {
            "Authorization": config.Key,
            "Content-Type": 'application/json'
        },
        json: true,
        uri: "https://api.corebot.dev/api/v1/client/license/validate"
    })
        .then(async result => {
            const response = typeof result == "string" ? result.toLowerCase() : "";
            if (response == "ok") {
                console.log(Utils.infoPrefix + "Your bot's license key has been verified.");
                module.exports.m52hJwH65M = true;
            } else {
                console.log(Utils.errorPrefix + "License error (Code: 17). This may mean that your bot cannot connect to Corebot's license server.");
                process.exit();
            }
        })
        .catch(err => {
            if (err?.response?.body?.error) {
                if (err?.response?.body?.error == 1) {
                    console.log(Utils.errorPrefix + "Your license key is invalid! Shutting down... (Code: 94)");
                    process.exit();
                } else if (err?.response?.body?.error == 2) {
                    console.log(Utils.errorPrefix + "Your license key is invalid! Shutting down... (Code: 38)");
                    process.exit();
                }
            }

            if (Utils.getStartupParameters().includes("debug")) console.log(Utils.errorPrefix + `License error (Code: 59). Error: ${err}`);
            if (['StatusCodeError: 403 - "Forbidden"', 'StatusCodeError: 403 - {"error":"Not Authenticated"}'].includes(err.toString())) {
                console.log(Utils.errorPrefix + '\x1b[91m%s\x1b[0m', 'Bot key is invalid.');
                process.exit();
            }
        });
};
// 482836   8501   fe301c3d179b70474f80a8e91ed222b8    95994   1716144902   5c9e263b836636dc6ae9b0d8b27728aa   %%__NONCE__%%