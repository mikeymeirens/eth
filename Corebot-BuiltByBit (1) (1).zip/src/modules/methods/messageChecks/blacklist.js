const Utils = require("../../utils");
const { variables: { config, lang }, Embed } = Utils;

module.exports = async (messageOrInteraction, type, message, interaction, user, channel, guild, reply, member, validPrefixes, prefixFound, commandName, command) => {
    return new Promise(async (resolve, reject) => {
        if (!command) return resolve();
        if (!Utils.hasPermission(member, config.Moderation.CommandBlacklistBypass)) {
            let blacklists = await Utils.variables.db.get.getBlacklists(member) || [];
            if (blacklists.includes(command?.command) || blacklists.includes("all")) {
                reply(Embed({
                    color: config.EmbedColors.Error,
                    title: blacklists.includes("all") ? lang.ModerationModule.Commands.Blacklist.Embeds.Blacklist.Title[0] : lang.ModerationModule.Commands.Blacklist.Embeds.Blacklist.Title[1],
                }));
                return reject();
            }
        }

        return resolve();
    });
};
// 482836   8501   fe301c3d179b70474f80a8e91ed222b8    95994   1716144902   5c9e263b836636dc6ae9b0d8b27728aa   %%__NONCE__%%